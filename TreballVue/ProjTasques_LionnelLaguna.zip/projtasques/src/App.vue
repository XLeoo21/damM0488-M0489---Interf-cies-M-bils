<script setup>
import { ref } from 'vue'
import { RouterView } from 'vue-router'

const drawer = ref(false) // Estat reactiu del drawer lateral: true obert, false tancat

// Ítems del menú lateral amb ruta i icona
const items = [
  { title: 'Home', icon: 'mdi-home', route: '/' },                      // Enllaç a la pàgina principal
  { title: 'Nova tasca', icon: 'mdi-plus-box', route: '/newTask' },     // Enllaç per crear una nova tasca
  { title: 'Veure tasques', icon: 'mdi-format-list-bulleted', route: '/viewTasks' } // Enllaç per veure la llista de tasques
]
</script>

<template>
  <v-app>
    <!-- Drawer lateral: controlat per la propietat v-model="drawer" -->
    <v-navigation-drawer
      v-model="drawer" 
      app         
      temporary   
      scrim       
    >
      <v-list>
        <!-- Itera sobre els ítems del menú i crea un element per cada un -->
        <v-list-item
          v-for="(item, index) in items"
          :key="index"
          :to="item.route"    
          link                
          @click="drawer = false" 
          active-class="text-blue"
        >
          <v-list-item-title class="d-flex align-center">
            <v-icon start>{{ item.icon }}</v-icon> <!-- Icona associada a l'ítem -->
            {{ item.title }}                        <!-- Text del títol de l'ítem -->
          </v-list-item-title>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>

    <!-- Barra superior de l'aplicació -->
    <v-app-bar color="blue" app class="position-relative">
      <v-app-bar-nav-icon @click="drawer = !drawer" /> <!-- Botó per obrir/tancar el drawer -->
      <v-toolbar-title
        style="position: absolute; left: 50%; transform: translateX(-50%); margin: 0; padding: 0; color: white;"
      >
        Tasques <!-- Títol centrat de la barra d'aplicació -->
      </v-toolbar-title>
    </v-app-bar>

    <!-- Contingut principal on es renderitzen les rutes -->
    <v-main class="app-main">
      <v-container fluid class="pa-0">
        <RouterView /> <!-- Placeholder per al component associat a la ruta actual -->
      </v-container>
    </v-main>
  </v-app>
</template>

