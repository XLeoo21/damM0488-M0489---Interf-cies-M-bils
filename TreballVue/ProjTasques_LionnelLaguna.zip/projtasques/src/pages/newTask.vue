<script setup>
import { ref, computed } from 'vue'

// -----------------------------
// LÍMITS
// -----------------------------
const MAX_TITLE_LENGTH = 80 // ajusta este valor si quieres otro límite

// -----------------------------
// ESTAT DEL FORMULARI
// -----------------------------
const newTask = ref({
  title: '',        // Títol de la tasca
  description: '',  // Descripció de la tasca
  completed: false, // Estat: completada (true) o pendent (false)
})

// -----------------------------
// VALIDACIÓ DEL TÍTOL
// -----------------------------
const isTitleValid = computed(() => Boolean(newTask.value.title.trim())) // true si el títol no està buit
const titleErrorMessage = computed(() =>
  !newTask.value.title.trim() ? 'El títol no pot estar buit' : '' // missatge d'error si està buit
)

// -----------------------------
// COLOR DINÀMIC DEL SWITCH
// -----------------------------
const switchColor = computed(() => (newTask.value.completed ? 'green' : 'orange')) // verd si completada, taronja si pendent

// -----------------------------
// CONTROL DEL MISSATGE DE CONFIRMACIÓ
// -----------------------------
const showSuccess = ref(false) // true quan la tasca s'ha afegit correctament

// -----------------------------
// FUNCIONALITAT PER A AFEGIR LA TASCA
// -----------------------------
function addTask() {
  // No afegim si el títol està buit
  if (!isTitleValid.value) return

  // Assegurar que el títol no sobrepassi el màxim abans de guardar
  if (newTask.value.title.length > MAX_TITLE_LENGTH) {
    newTask.value.title = newTask.value.title.slice(0, MAX_TITLE_LENGTH).trim()
  }

  // Recuperem les tasques existents des de localStorage
  const storedTasks = JSON.parse(localStorage.getItem('tasks') || '[]')

  // Afegim la nova tasca amb un id únic basat en la data/hora
  storedTasks.push({
    id: Date.now(),                 // identificador únic
    title: newTask.value.title,     // títol de la tasca
    description: newTask.value.description, // descripció
    completed: newTask.value.completed      // estat completat o pendent
  })

  // Guardem l'array actualitzat a localStorage
  localStorage.setItem('tasks', JSON.stringify(storedTasks))

  // Neteja el formulari per a una nova tasca
  newTask.value = { title: '', description: '', completed: false }

  // Mostra el missatge de confirmació durant 3 segons
  showSuccess.value = true
  setTimeout(() => { showSuccess.value = false }, 3000)
}
</script>

<template>
  <v-container class="py-6" max-width="600">
    <v-card class="pa-6" elevation="6">
      <!-- Títol del formulari -->
      <h2 class="text-h5 mb-6 text-center">Afegir una nova tasca</h2>

      <!-- ALERTA DE CONFIRMACIÓ -->
      <v-alert
        v-if="showSuccess"
        type="success"
        border="left"
        colored-border
        class="mb-4"
        elevation="2"
      >
        Tasca afegida correctament!
      </v-alert>

      <!-- FORMULARI -->
      <v-form @submit.prevent="addTask" class="d-flex flex-column gap-4">
        <!-- CAMP DEL TÍTOL AMB ERROR DINÀMIC -->
        <v-text-field
          v-model="newTask.title"
          label="Títol"
          :error="!isTitleValid"
          :error-messages="titleErrorMessage"
          dense
          outlined
          required
          :counter="MAX_TITLE_LENGTH"
          :maxlength="MAX_TITLE_LENGTH"
        />

        <!-- CAMP DE DESCRIPCIÓ -->
        <v-textarea
          v-model="newTask.description"
          label="Descripció"
          rows="4"
          dense
          outlined
        />

        <!-- SWITCH PER ESTAT -->
        <v-switch
          v-model="newTask.completed"
          :color="switchColor"
          :label="newTask.completed ? 'Completada' : 'Pendent'"
          inset
          density="comfortable"
        />

        <!-- BOTÓ AFEGIR -->
        <v-btn
          color="primary"
          type="submit"
          class="mt-4"
          :disabled="!isTitleValid"
          elevation="3"
          rounded
        >
          Afegir
        </v-btn>
      </v-form>
    </v-card>
  </v-container>
</template>
