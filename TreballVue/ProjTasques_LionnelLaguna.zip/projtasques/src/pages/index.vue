<template>
  <!-- Contenidor principal fluid que ocupa tota l'alçada disponible
       i centra el contingut horitzontalment deixant-lo a l'inici verticalment.
       pa-0 elimina padding; pt-16 afegeix padding superior perquè la imatge baixi una mica. -->
  <v-container fluid class="fill-height d-flex align-start justify-center pa-0 pt-16">
    <!-- Component d'imatge de Vuetify:
         - src apunta a l'arxiu d'assets,
         - alt text descriptiu per accessibilitat,
         - contain fa que la imatge s'ajusti dins del contenidor sense retallar-se,
         - max-width i max-height limiten les dimensions,
         - class mx-auto centra la imatge en l'eix horitzontal dins del container. -->
    <v-img
      src="@/assets/Tasques.png"
      alt="Tasques"
      contain
      max-width="250px"
      max-height="250px"
      class="mx-auto"
    />
  </v-container>
</template>