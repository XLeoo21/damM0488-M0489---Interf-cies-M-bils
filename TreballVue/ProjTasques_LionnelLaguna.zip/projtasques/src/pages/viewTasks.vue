<script setup>
// -----------------------------
// Imports de Vue
// ref → valors reactius, onMounted → executar en muntar, computed → valors derivats
// -----------------------------
import { ref, onMounted, computed } from 'vue' // Importa funcions de Vue per a reactivitat i cicle de vida

// -----------------------------
// Estat general
// -----------------------------
const tasks = ref([])                   // Llista reactiva de totes les tasques
const editDialog = ref(false)           // Controla si el diàleg d'edició està obert o tancat
const editedTask = ref(null)            // Desa temporalment la tasca que s’està editant
const deleteDialog = ref(false)         // Controla si el diàleg de confirmació d’eliminació està obert
const taskToDelete = ref(null)          // Desa la tasca seleccionada per eliminar

// -----------------------------
// LocalStorage: carregar i guardar
// -----------------------------
function loadTasks() {                  // Funció per carregar tasques del localStorage
  tasks.value = JSON.parse(localStorage.getItem('tasks') || '[]') // Llegeix tasques guardades o retorna array buit
}
function saveTasks() {                  // Funció per guardar tasques al localStorage
  localStorage.setItem('tasks', JSON.stringify(tasks.value))      // Desa les tasques com a JSON
}

// -----------------------------
// Validació del títol
// -----------------------------
const MAX_TITLE_LENGTH = 80             // **Límit de caràcters per al títol** (canvia segons necessitat)

const isEditedTitleValid = computed(() =>                    // Valor computat que indica si el títol és vàlid
  editedTask.value ? !!editedTask.value.title.trim() : true  // True si el títol té text, o si no hi ha tasca editant-se
)
const editedTitleError = computed(() =>                      // Valor computat que mostra missatge d'error
  editedTask.value && !editedTask.value.title.trim()          // Si hi ha tasca i el títol és buit...
    ? 'El títol no pot estar buit'                           // ...missatge d'error
    : ''                                                     // ...sinó, cap missatge
)

// -----------------------------
// Edició de tasques
// -----------------------------
function openEditDialog(task) {           // Obre diàleg d'edició per a una tasca
  editedTask.value = { ...task }          // Fa còpia de la tasca per no modificar directament
  editDialog.value = true                 // Mostra el diàleg
}
function saveEditedTask() {               // Desa els canvis de la tasca editada
  if (!isEditedTitleValid.value) return   // Si el títol no és vàlid, surt
  // Assegurar que el títol no sobrepassi el màxim abans de guardar
  if (editedTask.value && editedTask.value.title.length > MAX_TITLE_LENGTH) {
    editedTask.value.title = editedTask.value.title.slice(0, MAX_TITLE_LENGTH).trim()
  }
  const i = tasks.value.findIndex(t => t.id === editedTask.value.id) // Troba la posició de la tasca
  if (i !== -1) tasks.value[i] = { ...editedTask.value }     // Substitueix la tasca antiga
  saveTasks()                              // Desa al localStorage
  editDialog.value = false                 // Tanca el diàleg
}

// -----------------------------
// Eliminació de tasques
// -----------------------------
function confirmDelete(task) {             // Obre diàleg de confirmació per eliminar
  taskToDelete.value = task                // Desa tasca seleccionada temporalment
  deleteDialog.value = true                // Mostra diàleg
}
function deleteTask() {                    // Elimina tasca seleccionada
  tasks.value = tasks.value.filter(t => t.id !== taskToDelete.value.id) // Filtra array i elimina
  saveTasks()                              // Desa al localStorage
  deleteDialog.value = false               // Tanca diàleg
}

// -----------------------------
// Carregar dades al muntar
// -----------------------------
onMounted(loadTasks)                       // Carrega tasques del localStorage al muntar component
</script>

<template>
  <v-container class="py-6"> <!-- Contenidor principal amb padding vertical -->
    <h2 class="text-h5 mb-6 text-center">Llista de tasques</h2> <!-- Títol de la pàgina -->

    <!-- Missatge si no hi ha tasques -->
    <v-alert v-if="tasks.length === 0" type="info" border="start" colored-border>
      Encara no hi ha tasques. Afegeix-ne una des de "Nova tasca". <!-- Missatge informatiu -->
    </v-alert>

    <!-- Llista de tasques -->
    <v-row v-else dense> <!-- Fila responsive amb menys espai vertical -->
      <v-col v-for="task in tasks" :key="task.id" cols="12" md="6" lg="4"> <!-- Columna responsive per cada tasca -->
        <!-- card amb estil en línia per min-height i layout vertical -->
        <v-card class="pa-4" elevation="4" :style="{ minHeight: '200px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }">
          <div class="d-flex justify-space-between align-center mb-2"> <!-- Capçalera: títol + estat -->
            <!-- Títol truncat en una línia; el títol complet es mostra amb title -->
            <h3
              class="text-h6"
              :title="task.title"
              :style="{
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                maxWidth: 'calc(100% - 96px)',
                margin: 0
              }"
            >{{ task.title }}</h3> <!-- Títol de la tasca -->
            <v-chip
              :color="task.completed ? 'green' : 'orange'"
              text-color="white"
              label
              small
            >
              {{ task.completed ? 'Completada' : 'Pendent' }} <!-- Text del chip -->
            </v-chip>
          </div>

          <!-- Descripció truncada a 3 línies mitjançant propietats en línia -->
          <p
            class="text-body-2 mb-4"
            :style="{
              overflow: 'hidden',
              display: '-webkit-box',
              WebkitLineClamp: 3,
              WebkitBoxOrient: 'vertical',
              lineHeight: '1.2em',
              maxHeight: '3.6em',
              margin: '0 0 1rem 0'
            }"
          >{{ task.description || 'Sense descripció' }}</p> <!-- Descripció o text per defecte -->

          <div class="d-flex justify-end gap-2"> <!-- Botons acció -->
            <v-btn icon="mdi-pencil" color="blue" variant="text" @click="openEditDialog(task)" /> <!-- Botó editar -->
            <v-btn icon="mdi-delete" color="red" variant="text" @click="confirmDelete(task)" /> <!-- Botó eliminar -->
          </div>
        </v-card>
      </v-col>
    </v-row>

    <!-- Diàleg d'edició -->
    <v-dialog v-model="editDialog" max-width="500"> <!-- Diàleg controlat per editDialog -->
      <v-card>
        <v-card-title>Editar tasca</v-card-title> <!-- Títol diàleg -->
        <v-card-text> <!-- Cos del diàleg -->
          <!-- Limitar input del títol i mostrar comptador -->
          <v-text-field
            v-model="editedTask.title"
            label="Títol"
            required
            :error="!isEditedTitleValid"
            :error-messages="editedTitleError"
            :counter="MAX_TITLE_LENGTH"
            :maxlength="MAX_TITLE_LENGTH"
          />
          <v-textarea v-model="editedTask.description" label="Descripció" rows="3" /> <!-- Camp descripció -->
          <v-switch
            v-model="editedTask.completed"
            :label="editedTask.completed ? 'Completada' : 'Pendent'"
            color="green"
          />
        </v-card-text>
        <v-card-actions class="justify-end"> <!-- Botons acció -->
          <v-btn text color="grey" @click="editDialog = false">Cancel·lar</v-btn> <!-- Cancel·la edició -->
          <v-btn color="primary" @click="saveEditedTask" :disabled="!isEditedTitleValid">Guardar</v-btn> <!-- Desa canvis -->
        </v-card-actions>
      </v-card>
    </v-dialog>

    <!-- Diàleg d'eliminació -->
    <v-dialog v-model="deleteDialog" max-width="400"> <!-- Diàleg controlat per deleteDialog -->
      <v-card>
        <v-card-title>Confirmar eliminació</v-card-title> <!-- Títol -->
        <v-card-text> <!-- Cos del diàleg -->
          Segur que vols eliminar <strong>{{ taskToDelete?.title }}</strong>? <!-- Mostra títol tasca a eliminar -->
        </v-card-text>
        <v-card-actions class="justify-end"> <!-- Botons acció -->
          <v-btn text color="grey" @click="deleteDialog = false">Cancel·lar</v-btn> <!-- Cancel·la eliminació -->
          <v-btn color="red" @click="deleteTask">Eliminar</v-btn> <!-- Confirma eliminació -->
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>
